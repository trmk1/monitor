﻿Используемые плагины и скрипты:

0) Сам jQuery v1.3.1
site: http://jquery.com/

1) jQuery Multiple File Upload Plugin v1.31 (fix by me)
Плагин, позволяющий выбирать несколько файлов для загрузки.
site: http://www.fyneworks.com/jquery/multiple-file-upload/

2) jQuery Form Plugin v2.18
Плагин для ajax работы формочек.
site: http://malsup.com/jquery/form/

3) jQuery BlockUI Plugin v2.14
Красивые сообщения об ошибках
site: http://malsup.com/jquery/block/

4) doajaxfileupload.php
PHP-форма отправки файлов на сервер, написана исключительно для примера, но вполне работоспособна
site: http://spiritzzz.com/

собрал это чудо -  Егор SpirITzzz Дубровский 
site: http://spiritzzz.com/
icq: 204742439
